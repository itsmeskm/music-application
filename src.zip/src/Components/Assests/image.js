export const images = {
    tripBanner: require('./images/musician-349790_1280.jpeg'),
};